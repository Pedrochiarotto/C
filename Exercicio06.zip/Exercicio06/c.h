//Definição das structs
typedef struct{
    int ra;
    char nome[20];
    int idade;
    float media; 
}aluno;

//inicialização dos metodos

void ImprimirDados (aluno*, char,int, int, float); 

void ImprimirPonteiro (aluno*); 
