#include "c.c"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(){
     
    aluno *a =(aluno*)malloc(5 * sizeof(aluno)) ;
    int i, ra, idade;
    char nome[20];
    float media;  
    


    //Passando os argumentos para as funçoes
    for (i = 0; i<5; i++)
        {
        getchar();
        fgets(a[i]->nome,20, stdin);
        scanf("%d", &a[i]-> ra);
        scanf("%d", &a[i]-> idade);
        scanf("%f", &a[i]-> media);
    
    void ImprimirDados(a, a[i].nome, a[i].ra,a[i].idade, a[i].media);
    void ImprimirPonteiro(a); 
    i++; 
 }

    return 0; 
}
    
    
    


    
